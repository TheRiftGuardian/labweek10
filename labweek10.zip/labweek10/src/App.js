import './App.css';
import Form from './Form';

function App() {
	return (
		<div>
			Data Entry Form
			<Form />
		</div>
	);
}

export default App;
