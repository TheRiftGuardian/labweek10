import React, { Component } from 'react';

export default class Form extends Component {
	state = {
		email: '',
		fullName: '',
		address: '',
		address_2: '',
		city: '',
		province: '',
		postalCode: ''
	};

	onSubmit = (e) => {
		e.preventDefault();
		console.log(this.state);
	};

	render() {
		console.log(this.state.formData);
		return (
			<div>
				<form>
					<input
						name="email"
						placeholder="Enter email"
						value={this.state.email}
						onChange={(e) => this.setState({ email: e.target.value })}
					/>
					<br />
					<input
						name="fullName"
						placeholder="Full Name"
						value={this.state.fullName}
						onChange={(e) => this.setState({ fullName: e.target.value })}
					/>
					<br />
					<input
						name="address"
						placeholder="1234 Main St"
						value={this.state.address}
						onChange={(e) => this.setState({ address: e.target.value })}
					/>
					<br />
					<input
						name="address_2"
						placeholder="Apartment, studio, or floor"
						value={this.state.address_2}
						onChange={(e) => this.setState({ address_2: e.target.value })}
					/>
					<br />
					<input
						name="city"
						placeholder="City"
						value={this.state.city}
						onChange={(e) => this.setState({ city: e.target.value })}
					/>
					<br />
					<select value={this.state.pro} onChange={(e) => this.setState({ province: e.target.value })}>
						<option value="" disabled selected>
							Choose...
						</option>
						<option value="Alberta">Alberta</option>
						<option value="British Columbia">British Columbia</option>
						<option value="Manitoba">Manitoba</option>
						<option value="New Brunswick">New Brunswick</option>
						<option value="Newfoundland and Labrador">Newfoundland and Labrador</option>
						<option value="Nova Scotia">Nova Scotia</option>
						<option value="Ontario">Ontario</option>
						<option value="Prince Edward Island">Prince Edward Island</option>
						<option value="Quebec">Quebec</option>
						<option value="Saskatchewan">Saskatchewan</option>
					</select>
					<br />
					<input
						name="postalCode"
						value={this.state.postalCode}
						onChange={(e) => this.setState({ postalCode: e.target.value })}
					/>
					<br />
					<button onClick={(e) => this.onSubmit(e)}>Submit</button>
				</form>
				<h3>{'Email: ' + this.state.email}</h3>
				<h3>{'Name: ' + this.state.fullName}</h3>
				<h3>{'Address: ' + this.state.address}</h3>
				<h3>{'Address 2: ' + this.state.address_2}</h3>
				<h3>{'City: ' + this.state.city}</h3>
				<h3>{'Province: ' + this.state.province}</h3>
				<h3>{'Postal: ' + this.state.postalCode}</h3>
			</div>
		);
	}
}
